<?php   
	
	$message = array();
	
//	$message['0'] = "Invalid Username or Password!";
//
//	$message['1'] = "The Stream - Android TV Streaming";
//
//	$message['2'] = "Dashboard";
//	$message['3'] = "Category";
//	$message['4'] = "Channel";
//	$message['5'] = "Push Notification";
//	$message['6'] = "Settings";
//	$message['7'] = "Logout";
//
//	$message['8'] = "Delete successfully... ";
//	$message['9'] = "Updated successfully... ";
//
//	$message['10'] = "Ads Config";
//
//	$message['17'] = "notification send successfully...";

?>
