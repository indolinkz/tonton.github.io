<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/confirm-delete-member.php'); ?>
<?php include('public/footer.php'); ?>