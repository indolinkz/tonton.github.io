<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/dashboard_menu.php'); ?>
<?php include('public/footer.php'); ?>

